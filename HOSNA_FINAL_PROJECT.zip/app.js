(() => {
  const cfg = window.HOSNA_CONFIG;
  const gallery = document.getElementById("gallery");
  const status = document.getElementById("status");
  const count = document.getElementById("count");
  const dialog = document.getElementById("lightbox");
  const dialogImg = document.getElementById("lightboxImg");

  document.getElementById("productsBtn").addEventListener("click", () =>
    document.getElementById("productsSection").scrollIntoView({behavior:"smooth"})
  );

  document.getElementById("closeBtn").addEventListener("click", () => dialog.close());
  dialog.addEventListener("click", e => { if (e.target === dialog) dialog.close(); });

  const validImage = name => /\.(png|jpe?g|webp|gif)$/i.test(name);
  const sortNumeric = (a,b) => a.name.localeCompare(b.name, undefined, {numeric:true});

  function showImage(src, alt){
    dialogImg.src = src;
    dialogImg.alt = alt;
    dialog.showModal();
  }

  function render(files){
    gallery.innerHTML = "";
    files.sort(sortNumeric).forEach(file => {
      const button = document.createElement("button");
      button.className = "product";
      button.type = "button";

      const img = document.createElement("img");
      img.src = file.download_url;
      img.alt = `HOSNA Produkt ${file.name}`;
      img.loading = "lazy";
      img.decoding = "async";

      button.appendChild(img);
      button.addEventListener("click", () => showImage(img.src, img.alt));
      gallery.appendChild(button);
    });

    count.textContent = `${files.length} Bilder`;
    status.hidden = files.length > 0;
    if (!files.length) status.textContent = "Noch keine Produktbilder vorhanden.";
  }

  async function loadProducts(){
    const url = `https://api.github.com/repos/${cfg.githubOwner}/${cfg.githubRepo}/contents/${cfg.productsFolder}?ref=${cfg.githubBranch}`;
    try{
      const response = await fetch(url, {headers:{"Accept":"application/vnd.github+json"}});
      if(!response.ok) throw new Error(response.status);
      const files = await response.json();
      render(files.filter(f => f.type === "file" && validImage(f.name)));
    }catch(error){
      console.error(error);
      status.textContent = "Produkte konnten nicht geladen werden.";
      count.textContent = "0 Bilder";
    }
  }

  loadProducts();
})();
