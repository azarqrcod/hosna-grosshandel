window.HOSNA_CONFIG = {
  githubOwner: "azarqrcod",
  githubRepo: "hosna-grosshandel",
  githubBranch: "main",
  productsFolder: "products"
};
