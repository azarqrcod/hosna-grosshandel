# HOSNA Grosshandeln

## اطلاعات ثبت‌شده
- WhatsApp: +49 176 82096921
- E-Mail: Yasin_tabasum@yahoo.com
- Adresse: Herzbergstraße 128, Halle 6, Raum 638, 10365 Berlin
- AzarCore: https://azarqrcod.github.io/azarcore

## اینستاگرام
دکمه اینستاگرام فعلاً غیرفعال است. بعد از دریافت لینک، در `index.html` جایگزین شود.

## افزودن محصولات
عکس‌ها را داخل پوشه `products` قرار بده:
- 001.jpg
- 002.jpg
- 003.jpg

سایت آن‌ها را خودکار از GitHub API می‌خواند.

## انتشار
GitHub Pages:
Settings → Pages → Deploy from a branch → main / root
